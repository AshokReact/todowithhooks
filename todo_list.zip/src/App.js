import React, { useState } from "react";
import "./App.css";
function App() {
  const [inputs, setInputs] = useState("");
  const [items, setItems] = useState([]);
  const [All, setAll] = useState([]);

  const HandleChange = (e) => {
    setInputs(e.target.value);
  };
  const submitHandle = (e) => {
    e.preventDefault();
    if (!!inputs) {
      setItems([...items, { title: inputs, status: false }]);
      setAll([...items, { title: inputs, status: false }]);
    }
    setInputs("");
  };

  const handleCheckBox = (data) => (e) => {
    let result = items.map((ele) => {
      if (ele.title === data) {
        return {
          ...ele,
          status: e.target.checked,
        };
      } else {
        return ele;
      }
    });
    setAll(result);
    setItems(result);
  };

  const delteitem = (data) => {
    const filterdata = items.filter((ele) => {
      if (ele.title !== data) {
        return ele;
      }
    });
    setAll(filterdata);
    setItems(filterdata);
  };

  const activetodo = () => {
    const uncheck = items.filter((ele) => {
      if (ele.status === false) {
        return ele;
      }
    });
    setItems(uncheck);
  };

  const completestatus = () => {
    const completetodo = items.filter((ele) => {
      if (ele.status === true) {
        return ele;
      }
    });
    setItems(completetodo);
  };

  const allItems = () => {
    setItems(All);
  };
  return (
    <div className="main">
      <center>
        <h1
          style={{
            backgroundColor: "blue",
            color: "white",
            height: "80px",
            width: "600px",
          }}
        >
          Add TODO List!
        </h1>
        <form onSubmit={submitHandle}>
          <input
            type="text"
            name="todo"
            onChange={HandleChange}
            value={inputs}
            autoComplete="off"
            style={{ height: "35px", width: "450px" }}
          />
          <br />
          <br />
          <input value="submit" type="submit" style={{ height: "35px", width: "450px" }} />
        </form>
        <table class="table" style={{ width: "450px" }}>
          <tbody>
            {items.map((ele, index) => {
              return (
                <tr key={index}>
                  <td>
                    <ul>
                      <li></li>
                    </ul>
                  </td>
                  <td>
                    <input
                      type="checkbox"
                      value={ele.status}
                      checked={ele.status}
                      onChange={handleCheckBox(ele.title)}
                    ></input>
                  </td>
                  <td
                    style={{
                      textDecoration: `${ele.status ? "line-through" : ""}`,
                    }}
                  >
                    {ele.title}
                  </td>
                  <td>
                    <button
                      style={{ alignItems: "right" }}
                      onClick={() => delteitem(ele.title)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <table class="table" style={{ width: "600px", border: "1px solid" }}>
          <tbody>
            <tr>
              <td style={{ backgroundColor: "lightgray", width: "80px" }}>
                <button
                  style={{ border: "none", backgroundColor: "lightgray" }}
                  onClick={allItems}
                >
                  All Items
                </button>
              </td>
              <td style={{ backgroundColor: "lightgray", width: "60px" }}>
                <button
                  style={{ border: "none", backgroundColor: "lightgray" }}
                  onClick={activetodo}
                >
                  Acitve
                </button>
              </td>
              <td style={{ backgroundColor: "lightgray", width: "90px" }}>
                <button
                  style={{ border: "none", backgroundColor: "lightgray" }}
                  onClick={completestatus}
                >
                  Completed
                </button>
              </td>
              <td
                style={{
                  backgroundColor: "#B36D6A",
                  color: "#endregion",
                  width: "220px",
                  color: "white",
                }}
              >
                {items.length} Items | Make use of context API to store data
              </td>
            </tr>
          </tbody>
        </table>
      </center>
    </div>
  );
}
export default App;
